# terr — terminal error translator

## Quick start

1. Unzip this folder anywhere.
2. Run it directly:
   ```
   node translate.js "your error text here"
   ```
   or make it a global command:
   ```
   npm link
   terr "your error text here"
   ```
3. Pipe a failing command straight in:
   ```
   python app.py 2>&1 | terr
   ```

No API key needed — this talks to a shared hosted backend.
If the maintainer gave you a different endpoint or access token, set:
```
export TERR_ENDPOINT="https://your-backend.example.com"
export TERR_TOKEN="..."
```
