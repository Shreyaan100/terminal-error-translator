#!/usr/bin/env node

const HELP = `
Terminal Error Translator (CLI)

Turns a raw terminal error into a plain-English explanation, a cause, and
copy-paste fix commands. Uses a shared hosted backend — no API key needed.

USAGE
  terr                          Read error from stdin (pipe it in)
  terr <file>                   Read error from a log file
  terr "<error text>"           Pass the error as an argument
  cmd_that_fails 2>&1 | terr    Pipe a failing command's output directly

OPTIONS
  --json           Print raw JSON instead of formatted output
  --no-color       Disable ANSI colors
  -h, --help       Show this help

SETUP (one-time, only if the host requires it)
  export TERR_ENDPOINT="https://your-backend.example.com"
  export TERR_TOKEN="..."   (only if the host set an access token)

EXAMPLES
  python app.py 2>&1 | terr
  terr error.log
  terr "ModuleNotFoundError: No module named 'requests'"
`;

const DEFAULT_ENDPOINT = process.env.TERR_ENDPOINT || 'https://terminal-error-translator.onrender.com';
const ACCESS_TOKEN = process.env.TERR_TOKEN || '';

const args = process.argv.slice(2);

if (args.includes('-h') || args.includes('--help')) {
  console.log(HELP);
  process.exit(0);
}

const useColor = !args.includes('--no-color') && process.stdout.isTTY !== false;
const jsonMode = args.includes('--json');

const positional = args.filter(a => !a.startsWith('-'));

const c = useColor
  ? {
      dim: s => `\x1b[2m${s}\x1b[0m`,
      amber: s => `\x1b[38;5;215m${s}\x1b[0m`,
      mint: s => `\x1b[38;5;115m${s}\x1b[0m`,
      coral: s => `\x1b[38;5;210m${s}\x1b[0m`,
      bold: s => `\x1b[1m${s}\x1b[0m`,
      blue: s => `\x1b[38;5;110m${s}\x1b[0m`,
    }
  : {
      dim: s => s, amber: s => s, mint: s => s, coral: s => s, bold: s => s, blue: s => s,
    };

function readStdin() {
  return new Promise(resolve => {
    if (process.stdin.isTTY) {
      resolve('');
      return;
    }
    let data = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', chunk => (data += chunk));
    process.stdin.on('end', () => resolve(data));
  });
}

async function getErrorText() {
  const fs = await import('fs');

  if (positional.length > 0) {
    const arg = positional.join(' ');
    try {
      if (fs.existsSync(arg) && fs.statSync(arg).isFile()) {
        return fs.readFileSync(arg, 'utf8');
      }
    } catch (_) {}
    return arg;
  }

  return readStdin();
}

async function translate(errorText) {
  const headers = { 'Content-Type': 'application/json' };
  if (ACCESS_TOKEN) headers['x-terr-token'] = ACCESS_TOKEN;

  const response = await fetch(`${DEFAULT_ENDPOINT.replace(/\/$/, '')}/translate`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ error: errorText }),
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const msg = data?.error || `Request failed with status ${response.status}`;
    throw new Error(msg);
  }

  return data;
}

function printFormatted(result) {
  const sevColor = result.severity === 'warning' ? c.amber : c.coral;
  console.log('');
  console.log(c.dim('┌─ ') + c.blue(result.environment || 'unknown environment') + c.dim('  ·  ') + sevColor(result.severity || 'error'));
  console.log('');
  console.log(c.bold(c.amber('What happened')));
  console.log(result.summary || '');
  console.log('');
  console.log(c.bold('Why it broke'));
  console.log(c.dim(result.why || ''));
  console.log('');

  if (result.steps && result.steps.length) {
    console.log(c.bold(c.mint('How to fix it')));
    result.steps.forEach((step, i) => {
      console.log(`  ${c.mint(String(i + 1) + '.')} ${c.bold(step.title || '')}`);
      if (step.detail) console.log(`     ${c.dim(step.detail)}`);
    });
    console.log('');
  }

  if (result.commands && result.commands.length) {
    console.log(c.bold('Run this'));
    result.commands.forEach(cmd => {
      console.log(`  ${c.dim('$')} ${c.mint(cmd)}`);
    });
    console.log('');
  }
}

async function main() {
  if (DEFAULT_ENDPOINT.includes('your-backend.example.com')) {
    console.error(c.coral('No backend configured.') + ' Set TERR_ENDPOINT to your deployed server URL.');
    process.exitCode = 1;
    return;
  }

  const errorText = (await getErrorText()).trim();

  if (!errorText) {
    console.error(c.coral('No error text given.') + ' Pipe input, pass a file, or pass the error as an argument.');
    console.log(HELP);
    process.exitCode = 1;
    return;
  }

  try {
    const result = await translate(errorText);
    if (jsonMode) {
      console.log(JSON.stringify(result, null, 2));
    } else {
      printFormatted(result);
    }
  } catch (err) {
    console.error(c.coral('Translation failed: ') + err.message);
    process.exitCode = 1;
  }
}

main();
